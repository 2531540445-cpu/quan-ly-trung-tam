(() => {
  const $  = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];

  const crumbEl = $('#crumb');
  const titleEl = $('#page-title');
  const toastEl = $('#toast');
  const sidebar = $('#sidebar');
  const scrim   = $('#scrim');

  /* ---------- điều hướng trang ---------- */
  function showPage(id){
    const target = document.getElementById(id);
    if(!target) return;
    $$('.page').forEach(p => p.classList.remove('show'));
    target.classList.add('show');
    titleEl.textContent = target.dataset.title || '';
    crumbEl.innerHTML = '<b>' + (target.dataset.crumb || '') + '</b>';
    setActiveNav(target.dataset.nav || id);
    window.scrollTo(0, 0);
    closeMobileSidebar();
  }

  function setActiveNav(key){
    $$('.nav-item, .nav-sub a').forEach(a => a.classList.remove('active'));
    $$('.nav-group').forEach(g => g.classList.remove('open'));
    const match = $(`.nav-item[data-page="${key}"], .nav-sub a[data-page="${key}"]`);
    if(match){
      match.classList.add('active');
      const group = match.closest('.nav-group');
      if(group) group.classList.add('open');
    }
    syncAria();
  }

  function syncAria(){
    $$('.nav-group').forEach(g => {
      const btn = g.querySelector('.nav-toggle');
      if(btn) btn.setAttribute('aria-expanded', g.classList.contains('open') ? 'true' : 'false');
    });
  }


  $$('.nav-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const group = btn.closest('.nav-group');
      const willOpen = !group.classList.contains('open');
      $$('.nav-group').forEach(g => g.classList.remove('open'));
      if(willOpen) group.classList.add('open');
      syncAria();
    });
  });

  /* ---------- modal ---------- */
  function openModal(id, what){
    const ov = document.getElementById(id);
    if(!ov) return;
    if(what){
      const w = $('#delete-what', ov);
      if(w) w.textContent = what;
    }
    ov.classList.add('open');
  }
  function closeModal(ov){ ov.classList.remove('open'); }

  /* ---------- toast ---------- */
  let toastTimer;
  function showToast(msg){
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2400);
  }

  /* ---------- click chung (điều hướng / modal / toast) ---------- */
  document.addEventListener('click', e => {
    const pageBtn = e.target.closest('[data-page]');
    if(pageBtn){ e.preventDefault(); showPage(pageBtn.dataset.page); return; }

    const modalBtn = e.target.closest('[data-modal]');
    if(modalBtn){ e.preventDefault(); openModal(modalBtn.dataset.modal, modalBtn.dataset.what); return; }

    const toastBtn = e.target.closest('[data-toast]');
    if(toastBtn) showToast(toastBtn.dataset.toast);

    const closeBtn = e.target.closest('[data-close]');
    if(closeBtn){
      const ov = closeBtn.closest('.overlay');
      if(ov) closeModal(ov);
      return;
    }

    if(e.target.classList.contains('overlay')) closeModal(e.target);
  });

  document.addEventListener('keydown', e => {
    if(e.key === 'Escape') $$('.overlay.open').forEach(closeModal);
  });

  /* ---------- phân trang (chỉ đổi trạng thái hiển thị) ---------- */
  $$('.pages a').forEach(a => {
    a.addEventListener('click', e => {
      e.preventDefault();
      $$('a', a.parentElement).forEach(x => x.classList.remove('active'));
      a.classList.add('active');
    });
  });

  /* ---------- tìm kiếm / lọc bảng ---------- */
  $$('input[data-filter]').forEach(inp => {
    inp.addEventListener('input', () => {
      const table = document.getElementById(inp.dataset.filter);
      if(!table) return;
      const q = inp.value.trim().toLowerCase();
      $$('tbody tr', table).forEach(tr => {
        tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  });

  $$('select[data-filter-col]').forEach(sel => {
    const [tableId, colIdx] = sel.dataset.filterCol.split('|');
    sel.addEventListener('change', () => {
      const table = document.getElementById(tableId);
      if(!table) return;
      const val = sel.value.trim().toLowerCase();
      $$('tbody tr', table).forEach(tr => {
        const cell = tr.children[Number(colIdx)];
        tr.style.display = (!val || (cell && cell.textContent.toLowerCase().includes(val))) ? '' : 'none';
      });
    });
  });

  /* ---------- sidebar trên mobile ---------- */
  function closeMobileSidebar(){
    sidebar.classList.remove('open');
    scrim.classList.remove('show');
  }
  $('#burger')?.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    scrim.classList.toggle('show');
  });
  scrim?.addEventListener('click', closeMobileSidebar);

  /* ---------- khởi tạo ---------- */
  showPage('dashboard');
})();